package com.kodilla.testing.calculator;

public class Calculator {
}
