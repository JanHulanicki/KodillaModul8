package com.kodilla.testing;

import com.kodilla.testing.user.SimpleUser;

public class TestingMain {
    public static void main(String[] args){
        //System.out.println("Modul 6. wprowadzenie do testowanie oprogramowania");
        SimpleUser simpleUser=new SimpleUser("theForumUser");
        String result =simpleUser.getUsername();
        if(result.equals("theForumUser")){
            System.out.println("test OK");
        }else{
            System.out.println("test error");
        }

    }


}
